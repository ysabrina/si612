#include "Particle.h"
#include "Adafruit_GFX.h"
#include "Adafruit_ST7735.h"


#define CS S3
#define RST D0
#define DC D1


Adafruit_ST7735 display = Adafruit_ST7735(CS, DC, RST);


#define WHITE  0xFFFF
#define BLACK  0x0000
#define PINK   0xFCB7
#define RED    0xF800


void drawRat();


void setup() {
 display.initR(INITR_REDTAB);
 display.fillScreen(WHITE);
 drawRat();
}


void loop() {
}


void drawRat() {
 display.fillScreen(WHITE);


 // LEFT EYE - sad, flat on top
 display.fillCircle(40, 44, 10, BLACK);
 display.fillRect(30, 32, 22, 13, WHITE);
 display.fillCircle(43, 50, 3, WHITE);


 // RIGHT EYE - sad, flat on top
 display.fillCircle(88, 44, 10, BLACK);
 display.fillRect(78, 32, 22, 13, WHITE);
 display.fillCircle(91, 50, 3, WHITE);


 // BROWS angled inward (sad)
 display.drawLine(28, 30, 48, 37, BLACK);
 display.drawLine(28, 31, 48, 38, BLACK);
 display.drawLine(28, 32, 48, 39, BLACK);
 display.drawLine(80, 37, 100, 30, BLACK);
 display.drawLine(80, 38, 100, 31, BLACK);
 display.drawLine(80, 39, 100, 32, BLACK);


 // NOSE
 display.fillRoundRect(60, 63, 8, 5, 2, PINK);
 display.fillRoundRect(61, 59, 6, 5, 2, PINK);
 display.fillRoundRect(62, 56, 4, 4, 2, PINK);
 display.drawLine(62, 56, 58, 68, BLACK);
 display.drawLine(62, 56, 70, 68, BLACK);
 display.drawLine(58, 68, 70, 68, BLACK);


 // CHEEK MARKS
 display.drawLine(18, 68, 28, 65, PINK);
 display.drawLine(16, 75, 27, 73, PINK);
 display.drawLine(18, 82, 28, 81, PINK);
 display.drawLine(100, 65, 110, 68, PINK);
 display.drawLine(101, 73, 112, 75, PINK);
 display.drawLine(100, 81, 110, 82, PINK);


 // FROWN - corners go DOWN, middle goes UP
 // left corner low, middle high, right corner low
 display.drawLine(30, 115, 45, 105, BLACK);
 display.drawLine(45, 105, 55, 98, BLACK);
 display.drawLine(55, 98, 64, 96, BLACK);
 display.drawLine(64, 96, 73, 98, BLACK);
 display.drawLine(73, 98, 83, 105, BLACK);
 display.drawLine(83, 105, 98, 115, BLACK);
 // thicken
 display.drawLine(30, 114, 45, 104, BLACK);
 display.drawLine(45, 104, 55, 97, BLACK);
 display.drawLine(55, 97, 64, 95, BLACK);
 display.drawLine(64, 95, 73, 97, BLACK);
 display.drawLine(73, 97, 83, 104, BLACK);
 display.drawLine(83, 104, 98, 114, BLACK);
}
